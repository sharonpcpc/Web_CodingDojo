    function CorporateToLogOut(element){
        element.innerHTML = "Log Out"
    }

    function CorporateToLogOut2 (element){
    element.innerHTML = "Log Out"
}

    function AreYouSure(element) {
        alert("You´re going to be re-directed to a registration form")
    }

    function removeLogo(element){
        element.remove();
    }
